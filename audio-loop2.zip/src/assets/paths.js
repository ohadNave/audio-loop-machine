export default [
    ["MazePolitics_120_Perc","Maze"],
    ["PAS3GROOVE1.03B","Groove"],
    ["SilentStar_120_Em_OrganSynth","Silent Star"],
    ["FUD_120_StompySlosh","Slosh"],
    ["GrooveB_120bpm_Tanggu","Tanggu"],
    ["120_future_funk_beats_25","Funk Beats"],
    ["120_stutter_breakbeats_16","Breakbeats"],
    ["electric guitar coutry slide 120bpm - B","Guitar"],
    ["Bass Warwick heavy funk groove on E 120 BPM","Heavy Funk"],
  ];